lst1=["Mike", "Danny", "Jim", "Annie"]
lst2=[4, 12, 7, 19]

data = list(zip(lst1, lst2))
sorted_data = sorted(data)
print(sorted_data)