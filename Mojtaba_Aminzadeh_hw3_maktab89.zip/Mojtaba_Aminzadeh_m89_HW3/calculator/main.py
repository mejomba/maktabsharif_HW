from exceptions import run, help_user

if __name__ == '__main__':
    help_user()
    while True:
        run()

