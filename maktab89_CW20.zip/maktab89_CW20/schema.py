from datetime import datetime
from pydantic import BaseModel
from typing import Optional


class Task(BaseModel):
    title: str
    content: str
    status: Optional[bool] = False
    published: Optional[bool] = True
    # created_at: datetime


class TaskOut(BaseModel):
    title: str
    content: str
    status: Optional[bool] = False
    published: Optional[bool] = True
    # created_at: datetime