class Settings:
    round_count = 3
